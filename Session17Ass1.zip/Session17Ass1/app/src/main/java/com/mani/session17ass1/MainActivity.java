package com.mani.session17ass1;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


public class MainActivity extends Activity implements View.OnClickListener {
    TextView startmusic,stopmusic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startmusic=(TextView) findViewById(R.id.tvstartmusic);
        stopmusic=(TextView) findViewById(R.id.tvstopmusic);
        startmusic.setOnClickListener(this);
        stopmusic.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.tvstartmusic:
                Intent startservices=new Intent(getApplicationContext(),MyService.class);
                startService(startservices);
                break;
            case R.id.tvstopmusic:
                Intent stopservices=new Intent(getApplicationContext(),MyService.class);
                stopService(stopservices);
                break;
        }
    }
}
